﻿using System;

namespace Algoritmo_Dijkstra
{
    class Program
    {
        const int INF = 9999;
        static void Main(string[] args)
        {
            int[,] matriceAdiacenze = new int[1, 1];
            int nodi, nodoIniziale, nodoFinale, partenza, arrivo, peso;
            string continuo = "s";
            Console.WriteLine("Inserire il numero di nodi: ");
            Int32.TryParse(Console.ReadLine(), out nodi);
            matriceAdiacenze = new int[nodi + 1, nodi + 1];
            while (continuo == "s")
            {
                Console.WriteLine("Inserisci il nodo di partenza:  ");
                Int32.TryParse(Console.ReadLine(), out partenza);
                Console.WriteLine("Inserisci il nodo di arrivo:  ");
                Int32.TryParse(Console.ReadLine(), out arrivo);
                Console.WriteLine("Inserisci il peso del tratto: ");
                Int32.TryParse(Console.ReadLine(), out peso);
                matriceAdiacenze[partenza, arrivo] = peso;
                matriceAdiacenze[arrivo, partenza] = peso;
                Console.WriteLine("Vuoi continuare? (s-n): ");
                continuo = Console.ReadLine();
            }

            for(int i = 0; i <= nodi; i++)
            {
                matriceAdiacenze[0, i] = i;
                for(int j = 0; j <= nodi; j++)
                {
                    if(j == 0)
                        matriceAdiacenze[i, j] = i;
                    if (matriceAdiacenze[i, j] == 0 && i != j)
                        matriceAdiacenze[i, j] = INF;
                }
            }
            stampa(matriceAdiacenze, nodi);
        }


        static void stampa(int[,] l, int n)
        {
            for (int i = 0; i <= n; i++)
            {
                for (int j = 0; j <= n; j++)
                    Console.Write(l[i, j] + " ");
                Console.Write("\n");
            }
        }

        static void Dijkstra(int[,] l,int n)
        {

        }

    }
}
